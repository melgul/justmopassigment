<?php

namespace App\Controller;

use App\Entity\Booking;
use App\Entity\Cleaner;
use App\Entity\Customer;
use App\Repository\BookingRepository;
use mysql_xdevapi\Exception;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class BookingInsertController extends AbstractController
{
    /**
     * @Route("/createBooking/{emp_id}/{cust_id}/{date}/{duration}", name="create_booking")
     */
    public function index($emp_id,$cust_id,$date,$duration, BookingRepository $bookingRepository)
    {


        try{
            $entityManager = $this->getDoctrine()->getManager();

            $cleaner = $entityManager->getRepository(Cleaner::class)->find(intval($emp_id));

            $customer = $entityManager->getRepository(Customer::class)->find(intval($cust_id));

            $booking = new Booking();
            $booking->setEmp($cleaner);
            $booking->getCust($customer);
            $booking->setBookingDate(new \DateTime($date));
            $booking->setDuration(intval($duration));


            $entityManager->persist($booking);
            $entityManager->flush();
        }
        catch (Exception $e){
            //create log in  DB 

            return new Response('Fail');
        }

        return new Response('Success');
    }
}
