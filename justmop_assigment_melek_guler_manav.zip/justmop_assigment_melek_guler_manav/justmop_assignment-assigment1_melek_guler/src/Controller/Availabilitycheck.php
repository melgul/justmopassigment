<?php

namespace App\Controller;

use App\Entity\Company;
use App\Repository\BookingRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;


class BookingController extends AbstractController
{

    /**
     * @Route("/checkAvaliability", name="check_avaliability")
     */
    public function index(BookingRepository $bookingRepository)
    {
        $raw_result = $bookingRepository->getOccupiedSlots(3);

        $processed_result_list = array();

        $daily_result_list = array();

        for ($idx = 0; $idx < count($raw_result)  ; $idx++){


            if($idx == 0){
                array_push($daily_result_list,$raw_result[$idx]);
            }
            else{
                $last_added_to_arr = \DateTime::createFromFormat('Y-m-d H:i:s', end($daily_result_list)['booking_date']);
                $last_added_to_arr->setTime(8,00,00);

                $bookingDate = \DateTime::createFromFormat('Y-m-d H:i:s', $raw_result[$idx]['booking_date']);
                $bookingDate->setTime(8,00,00);

                $day_interval = $bookingDate->diff($last_added_to_arr);

                if($day_interval->days == 0){
                    array_push($daily_result_list, $raw_result[$idx]);
                }
                else {
                    array_push($processed_result_list, $daily_result_list);
                    unset($daily_result_list);
                    $daily_result_list = array();
                    array_push($daily_result_list,$raw_result[$idx]);
                }
            }
        }

        array_push($processed_result_list, $daily_result_list);

        $avaliable_slots_for_alldays = array();
        $avaliable_slots = array();

        foreach ($processed_result_list as $daily_schedule){

            for ($idx = 0; $idx < count($daily_schedule)  ; $idx++) {

                $currDate = \DateTime::createFromFormat('Y-m-d H:i:s', $daily_schedule[$idx]['booking_date']);
                $currEndDate = \DateTime::createFromFormat('Y-m-d H:i:s', $daily_schedule[$idx]['booking_end_time']);

                if($idx == 0 && count($daily_schedule) > 1){
                    $tempCurrDate = new \DateTime( $currDate->format('Y-m-d H:i:s'));
                    if($tempCurrDate->sub(new \DateInterval('PT2H'))->format('H') >= 8) {

                        unset($tempCurrDate);
                        $tempCurrDate = new \DateTime( $currDate->format('Y-m-d H:i:s'));

                        array_push($avaliable_slots, ['start' => $tempCurrDate->setTime(8, 00, 00),
                            'end' => $currDate]);
                    }
                    else {
                        //not avaliable time slot
                    }
                }
                else if($idx == (count($daily_schedule)-1)){

                    //Corner case: should check previous one again
                    $prevEndDate = \DateTime::createFromFormat('Y-m-d H:i:s', $daily_schedule[($idx-1)]['booking_end_time']);
                    $interval = $currDate->diff($prevEndDate);

                    if($interval->h >= 2) {
                        array_push($avaliable_slots,['start'=> $prevEndDate,
                            'end' => $currDate]);
                    }

                    //Calculate last slot
                    $tempEndDate = new \DateTime($currEndDate->format('Y-m-d H:i:s'));
                    $tempEndDate->add(new \DateInterval('PT2H'));
                    if( $tempEndDate->format('H')< 22
                    || ($tempEndDate->format('H') == 22
                        && $tempEndDate->format('M') == 0)) {

                        unset($tempEndDate);
                        $tempEndDate = new \DateTime($currEndDate->format('Y-m-d H:i:s'));

                        array_push($avaliable_slots, ['start' => $currEndDate,
                            'end' => $tempEndDate->setTime(22, 00, 00)]);
                    }
                    else {
                        //not avaliable time slot
                    }
                }
                else{
                    $prevEndDate = \DateTime::createFromFormat('Y-m-d H:i:s', $daily_schedule[($idx-1)]['booking_end_time']);
                    $interval = $currDate->diff($prevEndDate);

                    if($interval->h >= 2) {
                        array_push($avaliable_slots,['start'=> $prevEndDate,
                            'end' => $currDate]);
                    }
                }
            }
            array_push($avaliable_slots_for_alldays, $avaliable_slots);
            unset($avaliable_slots);
            $avaliable_slots = array();
        }

        return $this->json([
            'avaliable_slots' => $avaliable_slots_for_alldays
        ]);
    }
}
