<?php


namespace App\Repository;


use App\Entity\Booking;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class BookingRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Booking::class);
    }

    private function getLastBookingDate($emp_id)
    {
        $conn = $this->getEntityManager()->getConnection();

        //Hardcoded sql do parameterized if there is time
        $sql = 'SELECT booking_date            
                FROM booking                                                
                WHERE emp_id = :id
                ORDER BY booking_date DESC
                LIMIT 1;';

        $statement = $conn->prepare($sql);
        $statement->execute(['id' => $emp_id]);

        return $statement->fetchAll();
    }

    public function getOccupiedSlots($emp_id): array
    {
        $conn = $this->getEntityManager()->getConnection();

        //Hardcoded sql do parameterized if there is time
        $sql = 'SELECT booking_date, duration,
                DATE_ADD(booking_date,interval duration hour) as booking_end_time
                FROM booking
                WHERE booking_date >= :start_date
                AND booking_date <= :end_date
                AND emp_id = :id
                ORDER BY booking_date ASC;';

        $last_booking_date = $this->getLastBookingDate($emp_id);

        $date = \DateTime::createFromFormat('Y-m-d H:i:s', $last_booking_date[0]['booking_date']);

        $end_date = $date->format('Y-m-d H:i:s');

        $now = new \DateTime();
        $now->setTime(8,00,00);
        $start_date =  $now->format('Y-m-d H:i:s');

        $statement = $conn->prepare($sql);
        $statement->execute(['start_date' => $start_date, 'end_date' => $end_date, 'id' => $emp_id]);

        return $statement->fetchAll();
    }
}