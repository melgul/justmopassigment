<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Booking
 *
 * @ORM\Table(name="booking", indexes={@ORM\Index(name="cust_id_idx", columns={"cust_id"}), @ORM\Index(name="emp_id_idx", columns={"emp_id"})})
 * @ORM\Entity
 */
class Booking
{
    /**
     * @var int
     *
     * @ORM\Column(name="seq", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $seq;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="booking_date", type="datetime", nullable=false)
     */
    private $bookingDate;

    /**
     * @var int
     *
     * @ORM\Column(name="duration", type="integer", nullable=false)
     */
    private $duration;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="insert_date", type="datetime", nullable=true)
     */
    private $insertDate;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="amend_date", type="datetime", nullable=true)
     */
    private $amendDate;

    /**
     * @var \Customer
     *
     * @ORM\ManyToOne(targetEntity="Customer")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="cust_id", referencedColumnName="id")
     * })
     */
    private $cust;

    /**
     * @var \Cleaner
     *
     * @ORM\ManyToOne(targetEntity="Cleaner")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="emp_id", referencedColumnName="id")
     * })
     */
    private $emp;

    public function getSeq(): ?int
    {
        return $this->seq;
    }

    public function getBookingDate(): ?\DateTimeInterface
    {
        return $this->bookingDate;
    }

    public function setBookingDate(\DateTimeInterface $bookingDate): self
    {
        $this->bookingDate = $bookingDate;

        return $this;
    }

    public function getDuration(): ?int
    {
        return $this->duration;
    }

    public function setDuration(int $duration): self
    {
        $this->duration = $duration;

        return $this;
    }

    public function getInsertDate(): ?\DateTimeInterface
    {
        return $this->insertDate;
    }

    public function setInsertDate(?\DateTimeInterface $insertDate): self
    {
        $this->insertDate = $insertDate;

        return $this;
    }

    public function getAmendDate(): ?\DateTimeInterface
    {
        return $this->amendDate;
    }

    public function setAmendDate(?\DateTimeInterface $amendDate): self
    {
        $this->amendDate = $amendDate;

        return $this;
    }

    public function getCust(): ?Customer
    {
        return $this->cust;
    }

    public function setCust(?Customer $cust): self
    {
        $this->cust = $cust;

        return $this;
    }

    public function getEmp(): ?Cleaner
    {
        return $this->emp;
    }

    public function setEmp(?Cleaner $emp): self
    {
        $this->emp = $emp;

        return $this;
    }


}
