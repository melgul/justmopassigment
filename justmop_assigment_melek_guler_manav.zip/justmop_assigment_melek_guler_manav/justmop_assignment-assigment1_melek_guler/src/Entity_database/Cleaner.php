<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Cleaner
 *
 * @ORM\Table(name="cleaner", indexes={@ORM\Index(name="cmp_id_idx", columns={"cmp_id"})})
 * @ORM\Entity
 */
class Cleaner
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=45, nullable=false)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="surname", type="string", length=45, nullable=false)
     */
    private $surname;

    /**
     * @var string
     *
     * @ORM\Column(name="contact_number", type="string", length=45, nullable=false)
     */
    private $contactNumber;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="insert_date", type="datetime", nullable=true)
     */
    private $insertDate;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="amend_date", type="datetime", nullable=true)
     */
    private $amendDate;

    /**
     * @var \Company
     *
     * @ORM\ManyToOne(targetEntity="Company")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="cmp_id", referencedColumnName="id")
     * })
     */
    private $cmp;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): self
    {
        $this->name = $name;

        return $this;
    }

    public function getSurname(): ?string
    {
        return $this->surname;
    }

    public function setSurname(string $surname): self
    {
        $this->surname = $surname;

        return $this;
    }

    public function getContactNumber(): ?string
    {
        return $this->contactNumber;
    }

    public function setContactNumber(string $contactNumber): self
    {
        $this->contactNumber = $contactNumber;

        return $this;
    }

    public function getInsertDate(): ?\DateTimeInterface
    {
        return $this->insertDate;
    }

    public function setInsertDate(?\DateTimeInterface $insertDate): self
    {
        $this->insertDate = $insertDate;

        return $this;
    }

    public function getAmendDate(): ?\DateTimeInterface
    {
        return $this->amendDate;
    }

    public function setAmendDate(?\DateTimeInterface $amendDate): self
    {
        $this->amendDate = $amendDate;

        return $this;
    }

    public function getCmp(): ?Company
    {
        return $this->cmp;
    }

    public function setCmp(?Company $cmp): self
    {
        $this->cmp = $cmp;

        return $this;
    }


}
