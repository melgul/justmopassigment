<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * MailQueue
 *
 * @ORM\Table(name="mail_queue", indexes={@ORM\Index(name="booking_seq_idx", columns={"booking_seq"})})
 * @ORM\Entity
 */
class MailQueue
{
    /**
     * @var int
     *
     * @ORM\Column(name="seq", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $seq;

    /**
     * @var string
     *
     * @ORM\Column(name="status", type="string", length=3, nullable=false, options={"default"="NEW","comment"="holds the current status of the email that will be sent"})
     */
    private $status = 'NEW';

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="insert_date", type="datetime", nullable=true)
     */
    private $insertDate;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="process_date", type="datetime", nullable=true)
     */
    private $processDate;

    /**
     * @var \DateTime|null
     *
     * @ORM\Column(name="amend_date", type="datetime", nullable=true)
     */
    private $amendDate;

    /**
     * @var \Booking
     *
     * @ORM\ManyToOne(targetEntity="Booking")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="booking_seq", referencedColumnName="seq")
     * })
     */
    private $bookingSeq;

    public function getSeq(): ?int
    {
        return $this->seq;
    }

    public function getStatus(): ?string
    {
        return $this->status;
    }

    public function setStatus(string $status): self
    {
        $this->status = $status;

        return $this;
    }

    public function getInsertDate(): ?\DateTimeInterface
    {
        return $this->insertDate;
    }

    public function setInsertDate(?\DateTimeInterface $insertDate): self
    {
        $this->insertDate = $insertDate;

        return $this;
    }

    public function getProcessDate(): ?\DateTimeInterface
    {
        return $this->processDate;
    }

    public function setProcessDate(?\DateTimeInterface $processDate): self
    {
        $this->processDate = $processDate;

        return $this;
    }

    public function getAmendDate(): ?\DateTimeInterface
    {
        return $this->amendDate;
    }

    public function setAmendDate(?\DateTimeInterface $amendDate): self
    {
        $this->amendDate = $amendDate;

        return $this;
    }

    public function getBookingSeq(): ?Booking
    {
        return $this->bookingSeq;
    }

    public function setBookingSeq(?Booking $bookingSeq): self
    {
        $this->bookingSeq = $bookingSeq;

        return $this;
    }


}
